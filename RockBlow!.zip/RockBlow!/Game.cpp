#include <SFML/Graphics.hpp>
#include <vector>
#include <cstdlib>
#include <string>
#include <fstream>;
#include <SFML/Audio.hpp>
using namespace sf;
using namespace std;
Texture car, car1;
Texture bomb52;
struct nuke
{
	int lextent=3, rextent=3, uextent=3, dextent=3;
	int blink = 1;
	int type;
	RectangleShape b52;
	int timer=200;
	nuke() 
	{
		b52.setSize(Vector2f(60, 60));
		b52.setTexture(&bomb52);
	}
};
struct bullet
{
	RectangleShape bull;
	int direct;
	bullet()
	{
		bull.setSize(Vector2f(10, 10));
		bull.setFillColor(Color::Black);
	}
};
struct vehicle
{
	vehicle() {
		rec.setSize(Vector2f(60, 60));
	}
	RectangleShape rec;
	int speed;
};
struct line
{
	line() {
		drop = 0;
	}
	vector <vehicle*> a;
	int yline;
	bool direction;
	bool drop;
	void update()
	{
		if (direction)
		{
			while (a.size() == 0)
			{
				vehicle *neo = new vehicle;
				neo->rec.setTexture(&car);		
				neo->rec.setPosition(Vector2f(900, yline));
				neo->speed = rand() % 6 + 3;
				a.push_back(neo);
				if (a[0]->rec.getPosition().x <= -60)
				{
					delete a[0];
					a.erase(a.begin());
				}
			}
			int ran = rand() % 99 + 1;
			if (ran < 3 && a[a.size() - 1]->rec.getPosition().x <= 840)
			{
				vehicle *neo = new vehicle;
				neo->rec.setTexture(&car);
				neo->rec.setPosition(Vector2f(900, yline));
				int tmp = a[a.size() - 1]->speed * 900 / (a[a.size() - 1]->rec.getPosition().x + 60);
				if (tmp != 3) neo->speed = rand() % (tmp - 3) + 3;
				else neo->speed = 3;
				a.push_back(neo);
			}
			for (int i = 0; i < a.size(); ++i)
			{
				a[i]->rec.move(-(a[i]->speed), 0);
				if (drop)
				{
					a[i]->rec.setPosition(a[i]->rec.getPosition().x, yline);
				}
			}
		}
		else {
			while (a.size() == 0)
			{
				{
					vehicle *neo = new vehicle;
					neo->rec.setTexture(&car1);
					neo->rec.setPosition(Vector2f(-60, yline));
					neo->speed = rand() % 6 + 3;
					a.push_back(neo);
				}
				if (a[0]->rec.getPosition().x >= 900)
				{
					delete a[0];
					a.erase(a.begin());
				}
			}
			int ran = rand() % 99 + 1;
			if (ran < 3 && a[a.size() - 1]->rec.getPosition().x >= 0)
			{
				vehicle *neo = new vehicle;
				neo->rec.setTexture(&car1);
				neo->rec.setPosition(Vector2f(-60, yline));
				int tmp = a[a.size() - 1]->speed * 900 / (900 - a[a.size() - 1]->rec.getPosition().x);
				if (tmp != 3) neo->speed = rand() % (tmp - 3) + 3;
				else neo->speed = 3;
				a.push_back(neo);
			}
			for (int i = 0; i < a.size(); ++i)
			{
				a[i]->rec.move((a[i]->speed), 0);
				if (drop)
				{
					a[i]->rec.setPosition(a[i]->rec.getPosition().x, yline);
				}
			}
		}
			drop = 0;
	}
	~line()
	{
		for (int i = 0; i < a.size(); ++i) delete a[i];
	}
};
void main() {
	Texture epicent, hor, vert;
	epicent.loadFromFile("epicenter.png");
	hor.loadFromFile("hori.png");
	vert.loadFromFile("verti.png");
	RectangleShape verti, hori;
	verti.setSize(Vector2f(60, 60));
	hori.setSize(Vector2f(60, 60));
	verti.setTexture(&vert);
	hori.setTexture(&hor);
	RectangleShape wall;
	Texture walle;
	bomb52.loadFromFile("ekun.png");
	walle.loadFromFile("pit.png");
	wall.setSize(Vector2f(60, 60));
	wall.setTexture(&walle);
	SoundBuffer sb1;
	sb1.loadFromFile("dash.wav");
	Sound dash;
	dash.setBuffer(sb1);
	SoundBuffer sb2;
	sb2.loadFromFile("invinci.wav");
	Sound invinci;
	invinci.setBuffer(sb2);
	Sound invinci2;
	invinci2.setBuffer(sb2);
	SoundBuffer sb3;
	sb3.loadFromFile("refill.wav");
	Sound refill;
	refill.setBuffer(sb3);
	SoundBuffer sb4;
	sb4.loadFromFile("kill.wav");
	Sound kill;
	kill.setBuffer(sb4);
	SoundBuffer sb5;
	sb5.loadFromFile("land.wav");
	Sound land;
	land.setBuffer(sb5);
	SoundBuffer sb6;
	sb6.loadFromFile("cannon.wav");
	Sound cannon;
	cannon.setBuffer(sb6);
	SoundBuffer sb7;
	sb7.loadFromFile("blow.wav");
	Sound blow;
	blow.setBuffer(sb7);
	Texture textmp;
	textmp.loadFromFile("void.png");
	Texture textmp1;
	textmp1.loadFromFile("death.png");
	Texture textmp2;
	textmp2.loadFromFile("quake.png");
	RectangleShape quake;
	quake.setSize(Vector2f(60, 60));
	quake.setTexture(&textmp2);
	Texture textmp3;
	textmp3.loadFromFile("shadow.png");
	RectangleShape shadow;
	shadow.setSize(Vector2f(60, 60));
	shadow.setTexture(&textmp3);
	RectangleShape dead;
	dead.setSize(Vector2f(60, 60));
	dead.setTexture(&textmp1);
	vector <bullet> bullray;
	vector <bullet> bullray2;
	RectangleShape hp;
	RectangleShape mana1;
	RectangleShape special1;
	RectangleShape special2;
	RectangleShape special3;
	RectangleShape weapon;
	RectangleShape mana2;
	RectangleShape mana3;
	hp.setSize(Vector2f(60, 60));
	hp.setFillColor(Color::Red);
	mana1.setSize(Vector2f(60, 60));
	mana1.setFillColor(Color::Blue);
	special1.setSize(Vector2f(60, 60));
	special1.setFillColor(Color::Yellow);
	special2.setSize(Vector2f(60, 60));
	special2.setFillColor(Color::Magenta);
	special3.setSize(Vector2f(60, 60));
	special3.setFillColor(Color::Cyan);
	weapon.setSize(Vector2f(60, 60));
	weapon.setTexture(&textmp);
	mana2.setSize(Vector2f(60, 60));
	mana2.setFillColor(Color::Black);
	mana3.setSize(Vector2f(60, 60));
	mana3.setFillColor(Color(150,100,50));
	RectangleShape hpx2;
	RectangleShape mana1x2;
	RectangleShape jx2;
	RectangleShape special1x2;
	RectangleShape special2x2;
	RectangleShape special3x2;
	RectangleShape weaponx2;
	RectangleShape mana2x2;
	RectangleShape mana3x2;
	hpx2.setSize(Vector2f(60, 60));
	hpx2.setFillColor(Color::Red);
	mana1x2.setSize(Vector2f(60, 60));
	mana1x2.setFillColor(Color::Blue);
	special1x2.setSize(Vector2f(60, 60));
	special1x2.setFillColor(Color::Yellow);
	special2x2.setSize(Vector2f(60, 60));
	special2x2.setFillColor(Color::Magenta);
	special3x2.setSize(Vector2f(60, 60));
	special3x2.setFillColor(Color::Cyan);
	weaponx2.setSize(Vector2f(60, 60));
	weaponx2.setTexture(&textmp);
	mana2x2.setSize(Vector2f(60, 60));
	mana2x2.setFillColor(Color::Black);
	mana3x2.setSize(Vector2f(60, 60));
	mana3x2.setFillColor(Color(150, 100, 50));
	CircleShape circle;
	circle.setRadius(15);
	circle.setFillColor(Color::Magenta);
	Font font;
	font.loadFromFile("arial.ttf");
	Music music;
	music.openFromFile("forest.ogg");
	music.setLoop(1);
	SoundBuffer buffer, buffer1, buffer2, buffer3, buffer4, buffer5, buffer6;
	buffer.loadFromFile("walk.wav");
	Sound walk, error, hurt, die, fall, cursor, select;
	walk.setBuffer(buffer);
	buffer1.loadFromFile("error.wav");
	error.setBuffer(buffer1);
	buffer2.loadFromFile("hurt.wav");
	hurt.setBuffer(buffer2);
	buffer3.loadFromFile("die.wav");
	die.setBuffer(buffer3);
	buffer4.loadFromFile("fall.wav");
	fall.setBuffer(buffer4);
	buffer5.loadFromFile("cursor.wav");
	cursor.setBuffer(buffer5);
	buffer6.loadFromFile("select.wav");
	select.setBuffer(buffer6);
	int hs;
	ifstream fin;
	ofstream fout;
	bool loop = 1;
	RectangleShape lane;
	lane.setSize(Vector2f(900, 58));
	lane.setFillColor(Color::White);
	int score;
	Texture bomb;
	bomb.loadFromFile("Bomb.png");
	car.loadFromFile("Soldier.bmp");
	car1.loadFromFile("Soldier1.bmp");
	RenderWindow window(VideoMode(900, 600), "RockBlow!");
	window.setKeyRepeatEnabled(0);
	bool cont;
	Event event;
	RectangleShape player;
	player.setSize(Vector2f(60, 60));
	Texture texture1, texture2, texture3, texture4;
	texture1.loadFromFile("RalphUp.png");
	texture2.loadFromFile("RalphDown.png");
	texture3.loadFromFile("RalphLeft.png");
	texture4.loadFromFile("RalphRight.png");
	RectangleShape player2;
	player2.setSize(Vector2f(60, 60));
	player2.setFillColor(Color::Yellow);
	RectangleShape zebra;
	zebra.setSize(Vector2f(900, 2));
	zebra.setFillColor(Color::Black);
	float t;
	Clock clock;
	bool sprint;
	bool invin;
	bool sword;
	Keyboard::Key remem;
	int jmp;
	bool bighit;
	bool sprint2;
	bool invin2;
	bool sword2;
	Keyboard::Key remem2;
	int jmp2;
	bool bighit2;
	int winner;
	while(loop)
	{
		winner = 0;
		bighit = 0;
		remem = Keyboard::W;
		invin = 0;
		sprint = 0;
		sword = 0;
		jmp = 0;
		bighit2 = 0;
		remem2 = Keyboard::I;
		invin2 = 0;
		sprint2 = 0;
		sword2 = 0;
		jmp2 = 0;
		hp.setPosition(Vector2f(0, 540));
		mana1.setPosition(Vector2f(60, 540));
		special1.setPosition(Vector2f(120, 540));
		special2.setPosition(Vector2f(180, 540));
		mana2.setPosition(Vector2f(240, 540));
		special3.setPosition(Vector2f(300, 540));
		mana3.setPosition(Vector2f(360, 540));
		weapon.setPosition(Vector2f(-60, 0));
		hpx2.setPosition(Vector2f(480, 540));
		mana1x2.setPosition(Vector2f(540, 540));
		special1x2.setPosition(Vector2f(600, 540));
		special2x2.setPosition(Vector2f(660, 540));
		mana2x2.setPosition(Vector2f(720, 540));
		special3x2.setPosition(Vector2f(780, 540));
		mana3x2.setPosition(Vector2f(840, 540));
		weaponx2.setPosition(Vector2f(-60, 0));
		music.play();
		score = 0;
		cont = 1;
		player.setTexture(&texture1);
		player.setPosition(Vector2f(120, 480));
		player2.setTexture(&texture1);
		player2.setPosition(Vector2f(780, 480));
		bool map[15][10];
		for (int c = 0; c < 15; ++c) for (int v = 0; v < 10; ++v)
		{
			map[c][v] = 0;
			if (rand()%100<30) map[c][v] = 1;
		}
		map[2][8] = 0;
		map[12][18] = 0;
		line larray[4];
		int q = 0;
		int q2 = 0;
		for (int i = 0; i < 4; ++i)
		{
			larray[i].yline = i * 60 * (rand()%2+1);
			for (int c = 0; c < 15; c++) map[c][larray[i].yline / 60] = 0;
			larray[i].direction = rand()%2;
		}
		vector <nuke> nukearray;
		Clock clock1;
		while (cont)
		{
			for (int i = 0; i < 4; ++i)
			{
				for (int c = 0; c < 15; c++) map[c][larray[i].yline / 60] = 0;
			}
			window.pollEvent(event);
			if (sprint) 
			{
				bool chec = 0;
				int r = player.getPosition().x/60;
				if (r < player.getPosition().x / 60) chec = 1;
				int t = player.getPosition().y/60;
				bool bwall = 0;
				switch (remem)
				{
				case Keyboard::W:
					for (int y = 0; y < nukearray.size(); ++y)
					{
						if (nukearray[y].b52.getPosition().y == player.getPosition().y - 60 && abs(nukearray[y].b52.getPosition().x - player.getPosition().x) < 60) bwall = 1;
					}
					if (chec)
					{
						if (!map[r][t - 1] && !map[r + 1][t - 1]&&!bwall) {
							player.move(0, -60);
							dash.play();
							++score;
						}
						else error.play();
					}
					else if (!map[r][t - 1]) {
						if (!bwall)
						{
							player.move(0, -60);
							dash.play();
							++score;
						}
						else error.play();
					}
					else error.play();
					player.setTexture(&texture1);
					break;
				case Keyboard::S:
					for (int y = 0; y < nukearray.size(); ++y)
					{
						if (nukearray[y].b52.getPosition().y == player.getPosition().y + 60 && abs(nukearray[y].b52.getPosition().x - player.getPosition().x) < 60) bwall = 1;
					}
					if (chec)
					{
						if (!map[r][t + 1] && !map[r + 1][t + 1]&&!bwall)
						{
							player.move(0, +60);
							dash.play();
							--score;
						}
						else error.play();
					}
					else if (!map[r][t + 1]) {
						if (!bwall)
						{
							player.move(0, +60);
							dash.play();
							++score;
						}
					}
					player.setTexture(&texture2);
					break;
				case Keyboard::A:
					for (int y = 0; y < nukearray.size(); ++y)
					{
						if (nukearray[y].b52.getPosition().y == player.getPosition().y && player.getPosition().x - nukearray[y].b52.getPosition().x == 60) bwall = 1;
					}
					if (player.getPosition().x != 0&&!map[r-1][t]&&!bwall)
					{
						player.move(-30, 0);
						dash.play();
					}
					else if (chec)
					{
						if (!bwall)
						{
							player.move(-30, 0);
							dash.play();
						}
						else error.play();
					}
					else
					{
						error.play();
					}
					player.setTexture(&texture3);
					break;
				case Keyboard::D:
					for (int y = 0; y < nukearray.size(); ++y)
					{
						if (nukearray[y].b52.getPosition().y == player.getPosition().y && nukearray[y].b52.getPosition().x - player.getPosition().x == 60) bwall = 1;
					}
					if (player.getPosition().x != 840 && !map[r + 1][t]&&!bwall) {
						player.move(30, 0);
						dash.play();
					}
					else
					{
						error.play();
					}
					player.setTexture(&texture4);
				}
				sprint = 0;
			}
			else if (jmp>0)
			{
				--jmp;
				if (jmp == 0)
				{
					player.move(0, +60);
					bighit = 1;
					land.play();
					invin = 0;
				}
			}
			else
			{
				if (event.type == Event::Closed) cont = 0;
				if (event.type == Event::MouseButtonPressed)
				{
					if (event.mouseButton.button == Mouse::Button::Right)
					{
						if(mana1.getPosition().y <= 585)
						{
							bool chec = 0;
							int r = player.getPosition().x / 60;
							if (r < player.getPosition().x / 60) chec = 1;
							int t = player.getPosition().y / 60;
							bool bwall = 0;

							switch (remem)
							{
							case Keyboard::W:
								for (int y = 0; y < nukearray.size(); ++y)
								{
									if (nukearray[y].b52.getPosition().y == player.getPosition().y - 60 && abs(nukearray[y].b52.getPosition().x - player.getPosition().x) < 60) bwall = 1;
								}
								if (chec)
								{
									if (!map[r][t - 1] && !map[r + 1][t - 1]&&!bwall) {
										player.move(0, -60);
										dash.play();
										++score;
										mana1.move(0, 20);
									}
									else error.play();
								}
								else if (!map[r][t - 1]) {
									if (!bwall)
									{
										player.move(0, -60);
										dash.play();
										++score;
										mana1.move(0, 20);
									}
									else error.play();
								}
								else error.play();
								player.setTexture(&texture1);
								break;
							case Keyboard::S:
								for (int y = 0; y < nukearray.size(); ++y)
								{
									if (nukearray[y].b52.getPosition().y == player.getPosition().y + 60 && abs(nukearray[y].b52.getPosition().x - player.getPosition().x) < 60) bwall = 1;
								}
								if (chec)
								{
									if (!map[r][t + 1] && !map[r + 1][t + 1]&&!bwall)
									{
										player.move(0, +60);
										dash.play();
										--score;
										mana1.move(0, 20);
									}
									else error.play();
								}
								else if (!map[r][t + 1]) {
									if (!bwall)
									{
										player.move(0, +60);
										dash.play();
										++score;
										mana1.move(0, 20);
									}
								}
								else error.play();
								player.setTexture(&texture2);
								break;
							case Keyboard::A:
								for (int y = 0; y < nukearray.size(); ++y)
								{
									if (nukearray[y].b52.getPosition().y == player.getPosition().y && player.getPosition().x - nukearray[y].b52.getPosition().x == 60) bwall = 1;
								}
								if (player.getPosition().x != 0&& !map[r-1][t]&&!bwall)
								{
									player.move(-30, 0);
									dash.play();
									mana1.move(0, 20);
								}
								else if (chec)
								{
									if (!bwall)
									{
										player.move(-30, 0);
										dash.play();
									}
								}
								else
								{
									error.play();
								}
								player.setTexture(&texture3);
								break;
							case Keyboard::D:
								for (int y = 0; y < nukearray.size(); ++y)
								{
									if (nukearray[y].b52.getPosition().y == player.getPosition().y && nukearray[y].b52.getPosition().x - player.getPosition().x == 60) bwall = 1;
								}
								if (player.getPosition().x != 840 && !map[r+1][t]&&!bwall) {
									player.move(30, 0);
									dash.play();
									mana1.move(0, 20);
								}
								else
								{
									error.play();
								}
								player.setTexture(&texture4);
							}
							sprint = 1;
						}
						else error.play();
					}
					if (!sword&&event.mouseButton.button == Mouse::Button::Left)
					{
						if (mana2.getPosition().y <= 570&&bullray.size()<2)
						{
							bullet pellet;
							mana2.move(0, 30);
							switch (remem)
							{
							case Keyboard::W:
								pellet.bull.setPosition(Vector2f(player.getPosition().x + 25, player.getPosition().y - 10));
								pellet.direct = 1;
								break;
							case Keyboard::S:
								pellet.bull.setPosition(Vector2f(player.getPosition().x + 25, player.getPosition().y + 60));
								pellet.direct = 2;
								break;
							case Keyboard::A:
								pellet.bull.setPosition(Vector2f(player.getPosition().x + -10, player.getPosition().y + 25));
								pellet.direct = 3;
								break;
							case Keyboard::D:
								pellet.bull.setPosition(Vector2f(player.getPosition().x + 60, player.getPosition().y + 25));
								pellet.direct = 4;
							}
							bullray.push_back(pellet);
						}
						else error.play();
					}
				}
				if (event.type == Event::KeyPressed)
				{
					bool chec = 0;
					int r = player.getPosition().x / 60;
					if (r < player.getPosition().x / 60) chec = 1;
					int t = player.getPosition().y / 60;
					bool bwall = 0;
					switch (event.key.code)
					{
					case Keyboard::X:
						if (mana3.getPosition().y <= 570&&!chec)
						{
							nuke nuketmp;
							nuketmp.type = 0;
							nuketmp.b52.setPosition(Vector2f(player.getPosition().x, player.getPosition().y));
							nukearray.push_back(nuketmp);
							mana3.move(0, 30);
						}
						else error.play();
						break;
					case Keyboard::Z:
						if (mana3.getPosition().y <= 570&&!chec)
						{
							nuke nuketmp;
							nuketmp.type = 1;
							nuketmp.b52.setPosition(Vector2f(player.getPosition().x, player.getPosition().y));
							nukearray.push_back(nuketmp);
							mana3.move(0, 30);
						}
						else error.play();
						break;
					case Keyboard::Q:
						if (mana3.getPosition().y <= 570&&!chec)
						{
							nuke nuketmp;
							nuketmp.type = 2;
							nuketmp.b52.setPosition(Vector2f(player.getPosition().x, player.getPosition().y));
							nukearray.push_back(nuketmp);
							mana3.move(0, 30);
						}
						else error.play();
						break;
					case Keyboard::C:
						if (special3.getPosition().y == 540)
						{
							special3.move(0, 60);
							player.move(0, -60);
							jmp = 10;
							cannon.play();
							invin = 1;
						}
						else error.play();
						break;
					case Keyboard::F:
						if (mana1.getPosition().y > 540) mana1.move(0, -2);
						if (mana2.getPosition().y > 540) mana2.move(0, -2);
						if (mana3.getPosition().y > 540) mana3.move(0, -2);
						if (hp.getPosition().y > 540) hp.move(0, -1);
						if (special1.getPosition().y > 540) special1.move(0, -2);
						if (special2.getPosition().y > 540) special2.move(0, -2);
						if (special3.getPosition().y > 540) special3.move(0, -2);
						refill.play();
						break;
					case Keyboard::R:
						if (bullray.size() == 0)
						{
							if (special2.getPosition().y < 600)
							{
								sword = 1-sword;
							}
							else error.play();
						}
						break;
					case Keyboard::E:
						invinci.setLoop(1);
						if (special1.getPosition().y < 600)
						{
							invinci.play();
							invin = 1;
						}
						else error.play();
						break;
					case Keyboard::Space:
						while (cont)
						{
							select.play();
							window.clear(Color::White);
							Text tmp("GAME PAUSED\n\nCONTROL(PLAYER 1 - PLAYER 2)\nMOVEMENT : W/A/S/D - I/J/K/L\nSPRINT: RIGHT CLICK - RIGHT\nMEELEE : R - P\nRANGE : LEFTCLICK - LEFT\nSTOMP : C - PERIOD(.)\nINVINCIBLE : E - 0\nREFILL : F - SEMICOLON(;)\nBOMB(3 TYPES) : X/Z/Q - COMMA(,)/M/U", font);
							tmp.setCharacterSize(30);
							tmp.setStyle(sf::Text::Bold);
							tmp.setFillColor(sf::Color::Red);
							tmp.setPosition(Vector2f(60, 60));
							Text tmp1("CONTINUE", font);
							tmp1.setCharacterSize(30);
							tmp1.setStyle(sf::Text::Bold);
							tmp1.setFillColor(sf::Color::Red);
							tmp1.setPosition(Vector2f(300, 500));
							circle.setPosition(250, 505);
							window.clear(Color::White);
							window.draw(tmp);
							window.draw(tmp1);
							window.draw(circle);
							window.display();
							while (cont)
							{
								window.pollEvent(event);
								if (event.type == Event::Closed) cont = 0;
								if (event.type == Event::KeyPressed)
									switch (event.key.code)
									{
									case Keyboard::W:
										error.play();
										break;
									case Keyboard::S:
										error.play();
										break;
									case Keyboard::I:
										error.play();
										break;
									case Keyboard::K:
										error.play();
										break;
									case Keyboard::Enter:
										select.play();
										cont = 0;
									}
							}
						}
						cont = 1;
						break;
					case Keyboard::Escape:
						cont = 0;
						break;
					case Keyboard::W:
						for (int y = 0; y < nukearray.size(); ++y)
						{
							if (nukearray[y].b52.getPosition().y == player.getPosition().y - 60 && abs(nukearray[y].b52.getPosition().x - player.getPosition().x) < 60) bwall = 1;
						}
						if (chec)
						{
							if (!map[r][t - 1] && !map[r+1][t-1]&!bwall) {
								player.move(0, -60);
								walk.play();
								++score;
							}
							else error.play();
						}
						else if(!map[r][t - 1]) {
							if (!bwall)
							{
								player.move(0, -60);
								walk.play();
								++score;
							}
							else error.play();
						}
						else error.play();
						player.setTexture(&texture1);
						remem = event.key.code;
						break;
					case Keyboard::S:
						for (int y = 0; y < nukearray.size(); ++y)
						{
							if (nukearray[y].b52.getPosition().y == player.getPosition().y + 60 && abs(nukearray[y].b52.getPosition().x - player.getPosition().x) < 60) bwall = 1;
						}
						if (chec)
						{
							if (!map[r][t + 1] && !map[r+1][t+1]&&!bwall)
							{
								player.move(0, +60);
								walk.play();
								--score;
							}
							else error.play();
						}
						else if (!map[r][t + 1]) {
							if (!bwall)
							{
								player.move(0, +60);
								walk.play();
								++score;
							}
							else error.play();
						}
						else error.play();
						player.setTexture(&texture2);
						remem = event.key.code;
						break;
					case Keyboard::A:
						for (int y = 0; y < nukearray.size(); ++y)
						{
							if (nukearray[y].b52.getPosition().y == player.getPosition().y && player.getPosition().x-nukearray[y].b52.getPosition().x==60) bwall = 1;
						}
						if (player.getPosition().x != 0 && !map[r - 1][t]&&!bwall)
						{
							player.move(-30, 0);
							walk.play();
						}
						else if (chec)
						{
							if (!bwall)
							{
								player.move(-30, 0);
								walk.play();
							}
							else error.play();
						}
						else
						{
							error.play();
						}
						player.setTexture(&texture3);
						remem = event.key.code;
						break;
					case Keyboard::D:
						for (int y = 0; y < nukearray.size(); ++y)
						{
							if (nukearray[y].b52.getPosition().y == player.getPosition().y && nukearray[y].b52.getPosition().x - player.getPosition().x == 60) bwall = 1;
						}
						if (player.getPosition().x != 840 && !map[r + 1][t]&&!bwall) {
							player.move(30, 0);
							walk.play();
						}
						else
						{
							error.play();
						}
						player.setTexture(&texture4);
						remem = event.key.code;
					}
				}
			}
			if (sprint2)
			{
				bool chec = 0;
				int r = player2.getPosition().x / 60;
				if (r < player2.getPosition().x / 60) chec = 1;
				int t = player2.getPosition().y / 60;
				bool bwall = 0;
				switch (remem2)
				{
				case Keyboard::I:
					for (int y = 0; y < nukearray.size(); ++y)
					{
						if (nukearray[y].b52.getPosition().y == player2.getPosition().y - 60 && abs(nukearray[y].b52.getPosition().x - player2.getPosition().x) < 60) bwall = 1;
					}
					if (chec)
					{
						if (!map[r][t - 1] && !map[r + 1][t - 1] && !bwall) {
							player2.move(0, -60);
							dash.play();
							++score;
						}
						else error.play();
					}
					else if (!map[r][t - 1]) {
						if (!bwall)
						{
							player2.move(0, -60);
							dash.play();
							++score;
						}
						else error.play();
					}
					else error.play();
					player2.setTexture(&texture1);
					break;
				case Keyboard::K:
					for (int y = 0; y < nukearray.size(); ++y)
					{
						if (nukearray[y].b52.getPosition().y == player2.getPosition().y + 60 && abs(nukearray[y].b52.getPosition().x - player2.getPosition().x) < 60) bwall = 1;
					}
					if (chec)
					{
						if (!map[r][t + 1] && !map[r + 1][t + 1] && !bwall)
						{
							player2.move(0, +60);
							dash.play();
							--score;
						}
						else error.play();
					}
					else if (!map[r][t + 1]) {
						if (!bwall)
						{
							player2.move(0, +60);
							dash.play();
							++score;
						}
					}
					player2.setTexture(&texture2);
					break;
				case Keyboard::J:
					for (int y = 0; y < nukearray.size(); ++y)
					{
						if (nukearray[y].b52.getPosition().y == player2.getPosition().y && player2.getPosition().x - nukearray[y].b52.getPosition().x == 60) bwall = 1;
					}
					if (player2.getPosition().x != 0 && !map[r - 1][t] && !bwall)
					{
						player2.move(-30, 0);
						dash.play();
					}
					else if (chec)
					{
						if (!bwall)
						{
							player2.move(-30, 0);
							dash.play();
						}
						else error.play();
					}
					else
					{
						error.play();
					}
					player2.setTexture(&texture3);
					break;
				case Keyboard::L:
					for (int y = 0; y < nukearray.size(); ++y)
					{
						if (nukearray[y].b52.getPosition().y == player2.getPosition().y && nukearray[y].b52.getPosition().x - player2.getPosition().x == 60) bwall = 1;
					}
					if (player2.getPosition().x != 840 && !map[r + 1][t] && !bwall) {
						player2.move(30, 0);
						dash.play();
					}
					else
					{
						error.play();
					}
					player2.setTexture(&texture4);
				}
				sprint2 = 0;
			}
			else if (jmp2 > 0)
			{
				--jmp2;
				if (jmp2== 0)
				{
					player2.move(0, +60);
					bighit2 = 1;
					land.play();
					invin2 = 0;
				}
			}
			else
			{
				if (event.type == Event::KeyPressed)
				{
					bool chec = 0;
					int r = player2.getPosition().x / 60;
					if (r < player2.getPosition().x / 60) chec = 1;
					int t = player2.getPosition().y / 60;
					bool bwall = 0;
					switch (event.key.code)
					{
					case Keyboard::Right:
						if (mana1x2.getPosition().y < 585)
						{
							bool bwall = 0;
							switch (remem2)
							{
							case Keyboard::I:
								for (int y = 0; y < nukearray.size(); ++y)
								{
									if (nukearray[y].b52.getPosition().y == player2.getPosition().y - 60 && abs(nukearray[y].b52.getPosition().x - player2.getPosition().x) < 60) bwall = 1;
								}
								if (chec)
								{
									if (!map[r][t - 1] && !map[r + 1][t - 1] && !bwall) {
										player2.move(0, -60);
										dash.play();
										++score;
										mana1x2.move(0, 20);
									}
									else error.play();
								}
								else if (!map[r][t - 1]) {
									if (!bwall)
									{
										player2.move(0, -60);
										dash.play();
										++score;
										mana1x2.move(0, 20);
									}
									else error.play();
								}
								else error.play();
								player2.setTexture(&texture1);
								break;
							case Keyboard::K:
								for (int y = 0; y < nukearray.size(); ++y)
								{
									if (nukearray[y].b52.getPosition().y == player2.getPosition().y + 60 && abs(nukearray[y].b52.getPosition().x - player2.getPosition().x) < 60) bwall = 1;
								}
								if (chec)
								{
									if (!map[r][t + 1] && !map[r + 1][t + 1] && !bwall)
									{
										player2.move(0, +60);
										dash.play();
										--score;
										mana1x2.move(0, 20);
									}
									else error.play();
								}
								else if (!map[r][t + 1]) {
									if (!bwall)
									{
										player2.move(0, +60);
										dash.play();
										++score;
										mana1x2.move(0, 20);
									}
								}
								else error.play();
								player2.setTexture(&texture2);
								break;
							case Keyboard::J:
								for (int y = 0; y < nukearray.size(); ++y)
								{
									if (nukearray[y].b52.getPosition().y == player2.getPosition().y && player2.getPosition().x - nukearray[y].b52.getPosition().x == 60) bwall = 1;
								}
								if (player2.getPosition().x != 0 && !map[r - 1][t] && !bwall)
								{
									player2.move(-30, 0);
									dash.play();
									mana1x2.move(0, 20);
								}
								else if (chec)
								{
									if (!bwall)
									{
										player2.move(-30, 0);
										dash.play();
									}
								}
								else
								{
									error.play();
								}
								player2.setTexture(&texture3);
								break;
							case Keyboard::L:
								for (int y = 0; y < nukearray.size(); ++y)
								{
									if (nukearray[y].b52.getPosition().y == player2.getPosition().y && nukearray[y].b52.getPosition().x - player2.getPosition().x == 60) bwall = 1;
								}
								if (player2.getPosition().x != 840 && !map[r + 1][t] && !bwall) {
									player2.move(30, 0);
									dash.play();
									mana1x2.move(0, 20);
								}
								else
								{
									error.play();
								}
								player2.setTexture(&texture4);
							}
							sprint2 = 1;
						}
						else error.play();
						break;
					case Keyboard::Left:
						if (mana2x2.getPosition().y < 570 && bullray2.size() < 2)
						{
							bullet pellet;
							mana2x2.move(0, 30);
							switch (remem2)
							{
							case Keyboard::I:
								pellet.bull.setPosition(Vector2f(player2.getPosition().x + 25, player2.getPosition().y - 10));
								pellet.direct = 1;
								break;
							case Keyboard::K:
								pellet.bull.setPosition(Vector2f(player2.getPosition().x + 25, player2.getPosition().y + 60));
								pellet.direct = 2;
								break;
							case Keyboard::J:
								pellet.bull.setPosition(Vector2f(player2.getPosition().x + -10, player2.getPosition().y + 25));
								pellet.direct = 3;
								break;
							case Keyboard::L:
								pellet.bull.setPosition(Vector2f(player2.getPosition().x + 60, player2.getPosition().y + 25));
								pellet.direct = 4;
							}
							bullray2.push_back(pellet);
						}
						else error.play();
						break;
					case Keyboard::Comma:
						if (mana3x2.getPosition().y <= 570&&!chec)
						{
							nuke nuketmp;
							nuketmp.type = 0;
							nuketmp.b52.setPosition(Vector2f(player2.getPosition().x, player2.getPosition().y));
							nukearray.push_back(nuketmp);
							mana3x2.move(0, 30);
						}
						else error.play();
						break;
					case Keyboard::M:
						if (mana3x2.getPosition().y <= 570&&!chec)
						{
							nuke nuketmp;
							nuketmp.type = 1;
							nuketmp.b52.setPosition(Vector2f(player2.getPosition().x, player2.getPosition().y));
							nukearray.push_back(nuketmp);
							mana3x2.move(0, 30);
						}
						else error.play();
						break;
					case Keyboard::U:
						if (mana3x2.getPosition().y <= 570&&!chec)
						{
							nuke nuketmp;
							nuketmp.type = 2;
							nuketmp.b52.setPosition(Vector2f(player2.getPosition().x, player2.getPosition().y));
							nukearray.push_back(nuketmp);
							mana3x2.move(0, 30);
						}
						else error.play();
						break;
					case Keyboard::Period:
						if (special3x2.getPosition().y == 540)
						{
							special3x2.move(0, 60);
							player2.move(0, -60);
							jmp2 = 10;
							cannon.play();
							invin2 = 1;
						}
						else error.play();
						break;
					case Keyboard::SemiColon:
						if (mana1x2.getPosition().y > 540) mana1x2.move(0, -2);
						if (mana2x2.getPosition().y > 540) mana2x2.move(0, -2);
						if (mana3x2.getPosition().y > 540) mana3x2.move(0, -2);
						if (hpx2.getPosition().y > 540) hpx2.move(0, -1);
						if (special1x2.getPosition().y > 540) special1x2.move(0, -2);
						if (special2x2.getPosition().y > 540) special2x2.move(0, -2);
						if (special3x2.getPosition().y > 540) special3x2.move(0, -2);
						refill.play();
						break;
					case Keyboard::P:
						if (bullray2.size() == 0)
						{
							if (special2x2.getPosition().y < 600)
							{
								sword2 = 1-sword2;
							}
							else error.play();
						}
						break;
					case Keyboard::O:
						invinci2.setLoop(1);
						if (special1x2.getPosition().y < 600)
						{
							invinci2.play();
							invin2 = 1;
						}
						else error.play();
						break;
					case Keyboard::I:
						for (int y = 0; y < nukearray.size(); ++y)
						{
							if (nukearray[y].b52.getPosition().y == player2.getPosition().y - 60 && abs(nukearray[y].b52.getPosition().x - player2.getPosition().x) < 60) bwall = 1;
						}
						if (chec)
						{
							if (!map[r][t - 1] && !map[r + 1][t - 1] & !bwall) {
								player2.move(0, -60);
								walk.play();
								++score;
							}
							else error.play();
						}
						else if (!map[r][t - 1]) {
							if (!bwall)
							{
								player2.move(0, -60);
								walk.play();
								++score;
							}
							else error.play();
						}
						else error.play();
						player2.setTexture(&texture1);
						remem2 = event.key.code;
						break;
					case Keyboard::K:
						for (int y = 0; y < nukearray.size(); ++y)
						{
							if (nukearray[y].b52.getPosition().y == player2.getPosition().y + 60 && abs(nukearray[y].b52.getPosition().x - player2.getPosition().x) < 60) bwall = 1;
						}
						if (chec)
						{
							if (!map[r][t + 1] && !map[r + 1][t + 1] && !bwall)
							{
								player2.move(0, +60);
								walk.play();
								--score;
							}
							else error.play();
						}
						else if (!map[r][t + 1]) {
							if (!bwall)
							{
								player2.move(0, +60);
								walk.play();
								++score;
							}
							else error.play();
						}
						else error.play();
						player2.setTexture(&texture2);
						remem2 = event.key.code;
						break;
					case Keyboard::J:
						for (int y = 0; y < nukearray.size(); ++y)
						{
							if (nukearray[y].b52.getPosition().y == player2.getPosition().y && player2.getPosition().x - nukearray[y].b52.getPosition().x == 60) bwall = 1;
						}
						if (player2.getPosition().x != 0 && !map[r - 1][t] && !bwall)
						{
							player2.move(-30, 0);
							walk.play();
						}
						else if (chec)
						{
							if (!bwall)
							{
								player2.move(-30, 0);
								walk.play();
							}
							else error.play();
						}
						else
						{
							error.play();
						}
						player2.setTexture(&texture3);
						remem2 = event.key.code;
						break;
					case Keyboard::L:
						for (int y = 0; y < nukearray.size(); ++y)
						{
							if (nukearray[y].b52.getPosition().y == player2.getPosition().y && nukearray[y].b52.getPosition().x - player2.getPosition().x == 60) bwall = 1;
						}
						if (player2.getPosition().x != 840 && !map[r + 1][t] && !bwall) {
							player2.move(30, 0);
							walk.play();
						}
						else
						{
							error.play();
						}
						player2.setTexture(&texture4);
						remem2 = event.key.code;
					}
				}
			}
			window.clear(Color::Green);
			for (int h=0; h<15;++h) for (int k=0;k<10;++k) 
			{
				if (map[h][k])
				{
					wall.setPosition(Vector2f(h * 60, k * 60));
				}
				window.draw(wall);
			}
			if (jmp > 0)
			{
				shadow.setPosition(Vector2f(player.getPosition().x, player.getPosition().y+60));
				window.draw(shadow);
			}
			if (jmp2 > 0)
			{
				shadow.setPosition(Vector2f(player2.getPosition().x, player2.getPosition().y + 60));
				window.draw(shadow);
			}
			for (int i = -1; i < 600; i += 60)
			{
				zebra.setPosition(Vector2f(0, i));
				window.draw(zebra);
			}
			if (clock1.getElapsedTime().asSeconds() >= 20 || player.getPosition().y == 0 || player2.getPosition().y == 0)
			{
				for (int y = 0; y < nukearray.size(); ++y) nukearray[y].b52.move(0, 60);
				for (int k = 9; k > 0; --k) for (int h = 14; h > 0; --h) map[h][k] = map[h][k - 1];
				for (int h = 14; h > 0; --h)
				{
					if (rand() % 100 < 30) map[h][0] = 1;
				}
				for (int i = 0; i < 4; ++i)
				{
					larray[i].yline = (larray[i].yline + 60) % 600;
					larray[i].drop = 1;
				}
				player.move(0, +60);
				player2.move(0, +60);
				for (int g = 0; g < bullray.size(); ++g)
				{
					bullray[g].bull.move(0, 60);
				}
				for (int g = 0; g < bullray2.size(); ++g)
				{
					bullray2[g].bull.move(0, 60);
				}
				clock1.restart();
			}
			for (int i = 0; i < 4; ++i)
			{
				larray[i].update();
				lane.setPosition(0, larray[i].yline + 1);
				window.draw(lane);
				if (bighit&&player.getPosition().y == larray[i].yline)
				{
					larray[i].a.clear();
					quake.setPosition(Vector2f(player.getPosition().x - 60, player.getPosition().y));
					window.draw(quake);
					quake.setPosition(Vector2f(player.getPosition().x + 60, player.getPosition().y));
					window.draw(quake);
					bighit = 0;
					blow.play();
					if (!invin2&&player2.getPosition().y == larray[i].yline) 
					{
						hurt.play();
						if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 30));
						else {
							die.play();
							cont = 0;
							winner = 1;
						}
					}
				}
				else 
				for (int j = 0; j < larray[i].a.size(); ++j)
				{
					bool alive = 1;
					window.draw(larray[i].a[j]->rec);
					if (!invin&&larray[i].yline == player.getPosition().y&&abs(player.getPosition().x - larray[i].a[j]->rec.getPosition().x) < 40)
					{
						player.setTexture(&bomb);
						hurt.play();
						if (hp.getPosition().y<600) hp.move(Vector2f(0, 1));
						else {
							die.play();
							cont = 0;
							winner = 2;
						}
					}
					if (sword&&larray[i].yline == weapon.getPosition().y&&abs(weapon.getPosition().x - larray[i].a[j]->rec.getPosition().x) < 40) {
						larray[i].a.erase(larray[i].a.begin() + j);
						--j;
						alive = 0;
						kill.play();
					}
					for (int z = 0; z< bullray.size(); ++ z)
					{
						int q1, q2;
						q1 = bullray[z].bull.getPosition().x;
						q2 = bullray[z].bull.getPosition().y;
						if (abs(larray[i].yline + 30 - q2) <= 40 && abs(larray[i].a[j]->rec.getPosition().x + 30 - q1) <= 40) {
							dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
							larray[i].a.erase(larray[i].a.begin() + j);
							--j;
							alive = 0;
							kill.play();
							bullray.erase(bullray.begin() + z);
							window.draw(dead);
						}
					}
					if (alive)
					{
						for (int u = 0; u < nukearray.size(); ++u)
						{
							if (nukearray[u].timer <= 0)
							{
								float bx, by;
								bx = nukearray[u].b52.getPosition().x;
								by = nukearray[u].b52.getPosition().y;
								int cx, cy;
								cx = bx / 60;
								cy = by / 60;
								int g, h, k;
								switch (nukearray[u].type)
								{
								case 0:
									for (h = cx, k = 0, g = bx; k < 2 && g - 60 > 0 && !map[h - 1][cy]; g -= 60, h--, ++k)
									{
										hori.setPosition(Vector2f(g - 60, by));
										if (abs(larray[i].a[j]->rec.getPosition().x - hori.getPosition().x) < 60 && abs(larray[i].a[j]->rec.getPosition().y - hori.getPosition().y) < 60)
										{
											dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
											larray[i].a.erase(larray[i].a.begin() + j);
											--j;
											kill.play();
											window.draw(dead);
										}
									}
									for (h = cx, k = 0, g = bx; k < 2 && g + 60 < 900 && !map[h + 1][cy]; g += 60, h++, ++k)
									{
										hori.setPosition(Vector2f(g + 60, by));
										if (abs(larray[i].a[j]->rec.getPosition().x - hori.getPosition().x) < 60 && abs(larray[i].a[j]->rec.getPosition().y - hori.getPosition().y) < 60)
										{
											dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
											larray[i].a.erase(larray[i].a.begin() + j);
											--j;
											kill.play();
											window.draw(dead);
										}
									}
									for (h = cy, k = 0, g = by; k < 2 && g - 60 > 0 && !map[cx][h - 1]; g -= 60, h--, ++k)
									{
										verti.setPosition(Vector2f(bx, g - 60));
										if (abs(larray[i].a[j]->rec.getPosition().x - verti.getPosition().x) < 60 && abs(larray[i].a[j]->rec.getPosition().y - verti.getPosition().y) < 60)
										{
											dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
											larray[i].a.erase(larray[i].a.begin() + j);
											--j;
											kill.play();
											window.draw(dead);
										}
									}
									for (h = cy, k = 0, g = by; k < 2 && g + 60 < 600 && !map[cx][h + 1]; g += 60, h++, ++k)
									{
										verti.setPosition(Vector2f(bx, g + 60));
										if (abs(larray[i].a[j]->rec.getPosition().x - verti.getPosition().x) < 60 && abs(larray[i].a[j]->rec.getPosition().y - verti.getPosition().y) < 60)
										{
											dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
											larray[i].a.erase(larray[i].a.begin() + j);
											--j;
											kill.play();
											window.draw(dead);
										}
									}
									break;
								case 1:
									for (h = cy, k = 0, g = by; k < 3 && g - 60 > 0 && !map[cx][h - 1]; g -= 60, h--, ++k)
									{
										verti.setPosition(Vector2f(bx, g - 60));
										if (abs(larray[i].a[j]->rec.getPosition().x - verti.getPosition().x) < 60 && abs(larray[i].a[j]->rec.getPosition().y - verti.getPosition().y) < 60)
										{
											dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
											larray[i].a.erase(larray[i].a.begin() + j);
											--j;
											kill.play();
											window.draw(dead);
										}
									}
									for (h = cy, k = 0, g = by; k < 3 && g + 60 < 600 && !map[cx][h + 1]; g += 60, h++, ++k)
									{
										verti.setPosition(Vector2f(bx, g + 60));
										if (abs(larray[i].a[j]->rec.getPosition().x - verti.getPosition().x) < 60 && abs(larray[i].a[j]->rec.getPosition().y - verti.getPosition().y) < 60)
										{
											dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
											larray[i].a.erase(larray[i].a.begin() + j);
											--j;
											kill.play();
											window.draw(dead);
										}
									}
									break;
								case 2:
									for (h = cx, k = 0, g = bx; k < 3 && g - 60 > 0 && !map[h - 1][cy]; g -= 60, h--, ++k)
									{
										hori.setPosition(Vector2f(g - 60, by));
										if (abs(larray[i].a[j]->rec.getPosition().x - hori.getPosition().x) < 60 && abs(larray[i].a[j]->rec.getPosition().y - hori.getPosition().y) < 60)
										{
											dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
											larray[i].a.erase(larray[i].a.begin() + j);
											--j;
											kill.play();
											window.draw(dead);
										}
									}
									for (h = cx, k = 0, g = bx; k < 3 && g + 60 < 900 && !map[h + 1][cy]; g += 60, h++, ++k)
									{
										hori.setPosition(Vector2f(g + 60, by));
										if (abs(larray[i].a[j]->rec.getPosition().x - hori.getPosition().x) < 60 && abs(larray[i].a[j]->rec.getPosition().y - hori.getPosition().y) < 60)
										{
											dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
											larray[i].a.erase(larray[i].a.begin() + j);
											--j;
											kill.play();
											window.draw(dead);
										}
									}
								}
							}
						}
					}
				}
				if (bighit2&&player2.getPosition().y == larray[i].yline)
				{
					larray[i].a.clear();
					quake.setPosition(Vector2f(player2.getPosition().x - 60, player2.getPosition().y));
					window.draw(quake);
					quake.setPosition(Vector2f(player2.getPosition().x + 60, player2.getPosition().y));
					window.draw(quake);
					bighit2 = 0;
					blow.play();
					if (!invin&&player.getPosition().y == larray[i].yline) 
					{
						hurt.play();
						if (hp.getPosition().y < 600) hp.move(Vector2f(0, 30));
						else {
							die.play();
							cont = 0;
							winner = 2;
						}
					}
				}
				else
					for (int j = 0; j < larray[i].a.size(); ++j)
					{
						window.draw(larray[i].a[j]->rec);
						if (!invin2&&larray[i].yline == player2.getPosition().y&&abs(player2.getPosition().x - larray[i].a[j]->rec.getPosition().x) < 40)
						{
							player2.setTexture(&bomb);
							hurt.play();
							if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1));
							else {
								die.play();
								cont = 0;
								winner = 1;
							}
						}
						if (sword2&&larray[i].yline == weaponx2.getPosition().y&&abs(weaponx2.getPosition().x - larray[i].a[j]->rec.getPosition().x) < 40) {
							larray[i].a.erase(larray[i].a.begin() + j);
							--j;
							kill.play();
						}
						for (int z = 0; z < bullray2.size(); ++z)
						{
							int q1, q2;
							q1 = bullray2[z].bull.getPosition().x;
							q2 = bullray2[z].bull.getPosition().y;
							if (abs(larray[i].yline + 30 - q2) <= 40 && abs(larray[i].a[j]->rec.getPosition().x + 30 - q1) <= 40) {
								dead.setPosition(Vector2f(larray[i].a[j]->rec.getPosition().x, larray[i].yline));
								larray[i].a.erase(larray[i].a.begin() + j);
								--j;
								kill.play();
								bullray2.erase(bullray2.begin() + z);
								window.draw(dead);
							}
						}
					}
			}
			for (int u = 0; u < nukearray.size(); ++u)
			{
				nukearray[u].timer--;
				if (nukearray[u].timer > 100) window.draw(nukearray[u].b52);
				else if (nukearray[u].timer > 0)
				{
					if (nukearray[u].blink) window.draw(nukearray[u].b52);
					nukearray[u].blink = 1 - nukearray[u].blink;
				}
				else if (nukearray[u].timer >= -30)
				{
					blow.play();
					nukearray[u].b52.setTexture(&epicent);
					window.draw(nukearray[u].b52);
					if (abs(player.getPosition().x - nukearray[u].b52.getPosition().x) < 60 && abs(player.getPosition().y - nukearray[u].b52.getPosition().y) < 60)
					{
						hurt.play();
						if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
						else {
							die.play();
							cont = 0;
							winner = 2;
						}
					}
					if (abs(player2.getPosition().x - nukearray[u].b52.getPosition().x) < 60 && abs(player2.getPosition().y - nukearray[u].b52.getPosition().y) < 60)
					{
						hurt.play();
						if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
						else {
							die.play();
							cont = 0;
							winner = 1;
						}
					}
					float bx, by;
					bx = nukearray[u].b52.getPosition().x;
					by = nukearray[u].b52.getPosition().y;
					int cx, cy;
					cx = bx / 60;
					cy = by / 60;
					int g, h, k;
					switch (nukearray[u].type)
					{
					case 0:
						for (h = cx, k = 0, g = bx; k < 2 && g - 60 > 0 && !map[h - 1][cy]; g -= 60, h--, ++k)
						{
							hori.setPosition(Vector2f(g - 60, by));
							window.draw(hori);
							if (abs(player.getPosition().x - hori.getPosition().x) < 60 && abs(player.getPosition().y - hori.getPosition().y) < 60)
							{
								hurt.play();
								if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 2;
								}
							}
							if (abs(player2.getPosition().x - hori.getPosition().x) < 60 && abs(player2.getPosition().y - hori.getPosition().y) < 60)
							{
								hurt.play();
								if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 1;
								}
							}
						}
						if (k < 2 && g - 60 >0 && map[h - 1][cy] && nukearray[u].timer == -30)
						{
							map[h - 1][cy] = 0;
						}
						for (h = cx, k = 0, g = bx; k < 3 && g + 60 < 900 && !map[h + 1][cy]; g += 60, h++, ++k)
						{
							hori.setPosition(Vector2f(g + 60, by));
							window.draw(hori);
							if (abs(player.getPosition().x - hori.getPosition().x) < 60 && abs(player.getPosition().y - hori.getPosition().y) < 60)
							{
								hurt.play();
								if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 2;
								}
							}
							if (abs(player2.getPosition().x - hori.getPosition().x) < 60 && abs(player2.getPosition().y - hori.getPosition().y) < 60)
							{
								hurt.play();
								if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 1;
								}
							}
						}
						if (k < 2 && g + 60 < 900 && map[h + 1][cy] && nukearray[u].timer == -30)
						{
							map[h + 1][cy] = 0;
						}
						for (h = cy, k = 0, g = by; k < 2 && g - 60 > 0 && !map[cx][h - 1]; g -= 60, h--, ++k)
						{
							verti.setPosition(Vector2f(bx, g - 60));
							window.draw(verti);
							if (abs(player.getPosition().x - verti.getPosition().x) < 60 && abs(player.getPosition().y - verti.getPosition().y) < 60)
							{
								hurt.play();
								if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 2;
								}
							}
							if (abs(player2.getPosition().x - verti.getPosition().x) < 60 && abs(player2.getPosition().y - verti.getPosition().y) < 60)
							{
								hurt.play();
								if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 1;
								}
							}
						}
						if (k < 2 && g - 60 > 0 && map[cx][h - 1] && nukearray[u].timer == -30)
						{
							map[cx][h - 1] = 0;
						}
						for (h = cy, k = 0, g = by; k < 2 && g + 60 < 600 && !map[cx][h + 1]; g += 60, h++, ++k)
						{
							verti.setPosition(Vector2f(bx, g + 60));
							window.draw(verti);
							if (abs(player.getPosition().x - verti.getPosition().x) < 60 && abs(player.getPosition().y - verti.getPosition().y) < 60)
							{
								hurt.play();
								if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 2;
								}
							}
							if (abs(player2.getPosition().x - verti.getPosition().x) < 60 && abs(player2.getPosition().y - verti.getPosition().y) < 60)
							{
								hurt.play();
								if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 1;
								}
							}
						}
						if (k < 2 && g + 60 < 600 && map[cx][h + 1] && nukearray[u].timer == -30)
						{
							map[cx][h + 1] = 0;
						}
						break;
					case 1:
						for (h = cy, k = 0, g = by; k < 3 && g - 60 > 0 && !map[cx][h - 1]; g -= 60, h--, ++k)
						{
							verti.setPosition(Vector2f(bx, g - 60));
							window.draw(verti);
							if (abs(player.getPosition().x - verti.getPosition().x) < 60 && abs(player.getPosition().y - verti.getPosition().y) < 60)
							{
								hurt.play();
								if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 2;
								}
							}
							if (abs(player2.getPosition().x - verti.getPosition().x) < 60 && abs(player2.getPosition().y - verti.getPosition().y) < 60)
							{
								hurt.play();
								if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 1;
								}
							}
						}
						if (k < 3 && g - 60 > 0 && map[cx][h - 1] && nukearray[u].timer == -30)
						{
							map[cx][h - 1] = 0;
						}
						for (h = cy, k = 0, g = by; k < 3 && g + 60 < 600 && !map[cx][h + 1]; g += 60, h++, ++k)
						{
							verti.setPosition(Vector2f(bx, g + 60));
							window.draw(verti);
							if (abs(player.getPosition().x - verti.getPosition().x) < 60 && abs(player.getPosition().y - verti.getPosition().y) < 60)
							{
								hurt.play();
								if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 2;
								}
							}
							if (abs(player2.getPosition().x - verti.getPosition().x) < 60 && abs(player2.getPosition().y - verti.getPosition().y) < 60)
							{
								hurt.play();
								if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 1;
								}
							}
						}
						if (k < 3 && g + 60 < 600 && map[cx][h + 1] && nukearray[u].timer == -30)
						{
							map[cx][h + 1] = 0;
						}
						break;
					case 2:
						for (h = cx, k = 0, g = bx; k < 3 && g - 60 > 0 && !map[h - 1][cy]; g -= 60, h--, ++k)
						{
							hori.setPosition(Vector2f(g - 60, by));
							window.draw(hori);
							if (abs(player.getPosition().x - hori.getPosition().x) < 60 && abs(player.getPosition().y - hori.getPosition().y) < 60)
							{
								hurt.play();
								if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 2;
								}
							}
							if (abs(player2.getPosition().x - hori.getPosition().x) < 60 && abs(player2.getPosition().y - hori.getPosition().y) < 60)
							{
								hurt.play();
								if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 1;
								}
							}
						}
						if (k < 3 && g - 60 > 0 && map[h - 1][cy] && nukearray[u].timer == -30)
						{
							map[h - 1][cy] = 0;
						}
						for (h = cx, k = 0, g = bx; k < 3 && g + 60 < 900 && !map[h + 1][cy]; g += 60, h++, ++k)
						{
							hori.setPosition(Vector2f(g + 60, by));
							window.draw(hori);
							if (abs(player.getPosition().x - hori.getPosition().x) < 60 && abs(player.getPosition().y - hori.getPosition().y) < 60)
							{
								hurt.play();
								if (hp.getPosition().y < 600) hp.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 2;
								}
							}
							if (abs(player2.getPosition().x - hori.getPosition().x) < 60 && abs(player2.getPosition().y - hori.getPosition().y) < 60)
							{
								hurt.play();
								if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 1.5));
								else {
									die.play();
									cont = 0;
									winner = 1;
								}
							}
						}
						if (k < 3 && g + 60 < 900 && map[h + 1][cy] && nukearray[u].timer == -30)
						{
							map[h + 1][cy] = 0;
						}
					}
					if (nukearray[u].timer == -30) 
					{
						nukearray.erase(nukearray.begin() + u);
						--u;
					}
				}
			}
			if (bighit)
			{
				quake.setPosition(Vector2f(player.getPosition().x - 60, player.getPosition().y));
				window.draw(quake);
				quake.setPosition(Vector2f(player.getPosition().x + 60, player.getPosition().y));
				window.draw(quake);
				bighit = 0;
				blow.play();
				if (!invin2&&player2.getPosition().y == player.getPosition().y)
				{
					hurt.play();
					if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 30));
					else {
						die.play();
						cont = 0;
						winner = 1;
					}
				}
			}
			if (bighit2)
			{
				quake.setPosition(Vector2f(player2.getPosition().x - 60, player2.getPosition().y));
				window.draw(quake);
				quake.setPosition(Vector2f(player2.getPosition().x + 60, player2.getPosition().y));
				window.draw(quake);
				bighit2 = 0;
				blow.play();
				if (!invin&&player.getPosition().y == player2.getPosition().y)
				{
					hurt.play();
					if (hp.getPosition().y < 600) hp.move(Vector2f(0, 30));
					else {
						die.play();
						cont = 0;
						winner = 2;
					}
				}
			}
			for (int z = 0; z < bullray.size(); ++z)
			{
				bool heck = 1;
				switch (bullray[z].direct)
				{
				case 1:
					bullray[z].bull.move(0, -10);
					break;
				case 2:
					bullray[z].bull.move(0, 10);
					break;
				case 3:
					bullray[z].bull.move(-10, 0);
					break;
				case 4:
					bullray[z].bull.move(10, 0);
				}
				int q1, q2;
				q1 = bullray[z].bull.getPosition().x;
				q2 = bullray[z].bull.getPosition().y;
				if (!invin2&&abs(player2.getPosition().y + 30 - q2) <= 10 && abs(player2.getPosition().x + 30 - q1) <= 10)
				{
					hurt.play();
					if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 6));
					else {
						die.play();
						cont = 0;
						winner = 1;
					}
					bullray.erase(bullray.begin() + z);
					heck = 0;
				}
				for (int z1 = 0; z1 < bullray2.size(); ++z1)
				{
					if (abs(bullray2[z1].bull.getPosition().x-q1)<=20&& abs(bullray2[z1].bull.getPosition().y - q2)<=20)
					{
						window.draw(bullray[z].bull);
						window.draw(bullray2[z1].bull);
						bullray.erase(bullray.begin() + z);
						bullray2.erase(bullray2.begin() + z1);
						heck = 0;
					}
				}
				if (heck)
				{
					window.draw(bullray[z].bull);
					if (q1 <= -10 || q1 >= 900 || q2 <= -10 || q2 >= 600) bullray.erase(bullray.begin() + z);
				}
			}
			for (int z = 0; z < bullray2.size(); ++z)
			{
				window.draw(bullray2[z].bull);
				switch (bullray2[z].direct)
				{
				case 1:
					bullray2[z].bull.move(0, -10);
					break;
				case 2:
					bullray2[z].bull.move(0, 10);
					break;
				case 3:
					bullray2[z].bull.move(-10, 0);
					break;
				case 4:
					bullray2[z].bull.move(10, 0);
				}
				int q1, q2;
				q1 = bullray2[z].bull.getPosition().x;
				q2 = bullray2[z].bull.getPosition().y;
				if (!invin&&abs(player.getPosition().y + 30 - q2) <= 40 && abs(player.getPosition().x + 30 - q1) <= 40)
				{
					hurt.play();
					if (hp.getPosition().y < 600) hp.move(Vector2f(0, 6));
					else {
						die.play();
						cont = 0;
						winner = 2;
					}
					bullray2.erase(bullray2.begin() + z);
				}
				if (q1 <= -10 || q1 >= 900 || q2 <= -10 || q2 >= 600) bullray2.erase(bullray2.begin() + z);
			}
			if (sword)
			{
				switch (remem)
				{
				case Keyboard::W:
					weapon.setPosition(Vector2f(player.getPosition().x, player.getPosition().y - 60));
					break;
				case Keyboard::S:
					weapon.setPosition(Vector2f(player.getPosition().x, player.getPosition().y + 60));
					break;
				case Keyboard::A:
					weapon.setPosition(Vector2f(player.getPosition().x-60, player.getPosition().y));
					break;
				case Keyboard::D:
					weapon.setPosition(Vector2f(player.getPosition().x+60, player.getPosition().y));
				}
				float q1, q2;
				if (!invin2&&abs(player2.getPosition().y - weapon.getPosition().y) < 60 && abs(player2.getPosition().x - weapon.getPosition().x) < 60)
				{
					hurt.play();
					if (hpx2.getPosition().y < 600) hpx2.move(Vector2f(0, 2));
					else {
						die.play();
						cont = 0;
						winner = 1;
					}
				}
				if (abs(weaponx2.getPosition().y - weapon.getPosition().y) < 60 && abs(weaponx2.getPosition().x - weapon.getPosition().x) < 60)
				{
					sword = 0;
					sword2 = 0;
					kill.play();
				}
				window.draw(weapon);
				if (special2.getPosition().y < 600) special2.move(0, 0.5);
				else sword = 0;
			}
			if (sword2)
			{
				switch (remem2)
				{
				case Keyboard::I:
					weaponx2.setPosition(Vector2f(player2.getPosition().x, player2.getPosition().y - 60));
					break;
				case Keyboard::K:
					weaponx2.setPosition(Vector2f(player2.getPosition().x, player2.getPosition().y + 60));
					break;
				case Keyboard::J:
					weaponx2.setPosition(Vector2f(player2.getPosition().x - 60, player2.getPosition().y));
					break;
				case Keyboard::L:
					weaponx2.setPosition(Vector2f(player2.getPosition().x + 60, player2.getPosition().y));
				}
				if (!invin&&abs(player.getPosition().y - weaponx2.getPosition().y) < 60 && abs(player.getPosition().x - weaponx2.getPosition().x) < 60)
				{
					hurt.play();
					if (hp.getPosition().y < 600) hp.move(Vector2f(0, 2));
					else {
						die.play();
						cont = 0;
						winner = 2;
					}
				}
				window.draw(weaponx2);
				if (special2x2.getPosition().y < 600) special2x2.move(0, 0.5);
				else sword2 = 0;
			}
			if (invin)
			{
				if (special1.getPosition().y < 600)
				{
					if (!jmp) special1.move(0, 1);
				}
				else {
					invinci.stop();
					invin = 0;
				}
				if(jmp) window.draw(player);
				else
				{
					if (q == 1) window.draw(player);
					q = 1 - q;
				}
			}
			else window.draw(player);
			if (invin2)
			{
				if (special1x2.getPosition().y < 600)
				{
					if (!jmp2) special1x2.move(0, 1);
					special1x2.move(0, 1);
				}
				else {
					invinci2.stop();
					invin2 = 0;
				}
				if (jmp) window.draw(player);
				else
				{
					if (q2 == 1) window.draw(player2);
					q2 = 1 - q2;
				}
			}
			else window.draw(player2);
			window.draw(hp);
			if (mana1.getPosition().y > 540) mana1.move(0,-1);
			if (mana2.getPosition().y > 540) mana2.move(0, -1);
			window.draw(mana1);
			window.draw(mana2);
			window.draw(mana3);
			window.draw(special1);
			window.draw(special2);
			window.draw(special3);
			window.draw(hpx2);
			if (mana1x2.getPosition().y > 540) mana1x2.move(0, -1);
			if (mana2x2.getPosition().y > 540) mana2x2.move(0, -1);
			window.draw(mana1x2);
			window.draw(mana2x2);
			window.draw(mana3x2);
			window.draw(special1x2);
			window.draw(special2x2);
			window.draw(special3x2);
			window.display();
			clock.restart();
			do
			{
				t = clock.getElapsedTime().asSeconds();
			} while (t < 0.009);
			if (player.getPosition().y == 540)
			{
				fall.play();
				cont = 0;
				winner = 2;
				if (invin) invinci.stop();
				if (invin2) invinci2.stop();
			}
			if (player2.getPosition().y == 540) {
				fall.play();
				cont = 0;
				winner = 1;
				if (invin2) invinci2.stop();
				if (invin) invinci.stop();
			}
		}
		music.stop();
		window.clear(Color::White);
		string out1;
		out1 = "GAME OVER\nSCORE:  ";
		out1.append(to_string(score));
		out1.append("\nHIGH SCORE: ");
		fin.open("highscore.txt");
		fin >> hs;
		fin.close();
		if (score+score > hs)
		{
			hs = score+score;
			fout.open("highscore.txt");
			fout << score;
			fout.close();
		}
		out1.append(to_string(hs));
		out1.append("\nWINNER : PLAYER ");
		out1.append(to_string(winner));
		Text text(out1, font);
		text.setCharacterSize(30);
		text.setStyle(sf::Text::Bold);
		text.setFillColor(sf::Color::Red);
		text.setPosition(Vector2f(60, 60));
		Text text1("NEW GAME", font);
		text1.setCharacterSize(30);
		text1.setStyle(sf::Text::Bold);
		text1.setFillColor(sf::Color::Red);
		text1.setPosition(Vector2f(200, 300));
		Text text2("QUIT", font);
		text2.setCharacterSize(30);
		text2.setStyle(sf::Text::Bold);
		text2.setFillColor(sf::Color::Red);
		text2.setPosition(Vector2f(200, 400));
		Text text3("RESET", font);
		text3.setCharacterSize(30);
		text3.setStyle(sf::Text::Bold);
		text3.setFillColor(sf::Color::Red);
		text3.setPosition(Vector2f(200, 500));
		string out2;
		circle.setPosition(150, 305);
		cont = 1;
		while (cont)
		{
			window.pollEvent(event);
			if (event.type == Event::Closed) {
				cont = 0;
				loop = 0;
			}
			if (event.type == Event::KeyPressed)
				switch (event.key.code)
				{
				case Keyboard::W:
					if (circle.getPosition().y != 305) 
					{
						cursor.play();
						circle.move(0, -100);
					}
					else error.play();
					break;
				case Keyboard::S:
					if (circle.getPosition().y != 505)
					{
						cursor.play();
						circle.move(0, +100);
					}
					else error.play();
					break;
				case Keyboard::I:
					if (circle.getPosition().y != 305)
					{
						cursor.play();
						circle.move(0, -100);
					}
					else error.play();
					break;
				case Keyboard::K:
					if (circle.getPosition().y != 505)
					{
						cursor.play();
						circle.move(0, +100);
					}
					else error.play();
					break;
				case Keyboard::Enter:
					cont = 0;
					select.play();
					if (circle.getPosition().y == 405) loop = 0;
					else if (circle.getPosition().y == 505)
					{
						fout.open("highscore.txt");
						fout << -1;
						fout.close();
						cont = 1;
					}
				}
			window.clear(Color::White);
			window.draw(text);
			window.draw(text1);
			window.draw(text2);
			window.draw(text3);
			window.draw(circle);
			window.display();
			clock.restart();
			do
			{
				t = clock.getElapsedTime().asSeconds();
			} while (t < 0.05);
		}
	}
	window.close();
}
